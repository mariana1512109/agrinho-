 var img;
 
function preload(){
img = loadImage("Canva2.png"); //imagem de fundo 
}

function setup() {
  createCanvas(600, 400);
}
//comentarios escondidos
function draw() {
  background( img);
   
  fill("rgb(12,0,2)")
  line(300,0,300,400);//linha do meio
  textSize(100);
  //CAMPO 
  text("🌳",190,250);//árvore
   textSize(130);
  text("🏡",0,230);//casa
   textSize(50);
  text("🐓",20,300);//galinha
  textSize(20);
  text("🐤",70,300);//pintinho 1
  text("🐤",150,300);//pintinho 2
  text("🐤",75,320);//pintinho 3
  text("🐤",7,320);//pintinho 4
  textSize(30);
  text("🚜",150,200);//trator
  //CIDADE
  textSize(100)
  text("🏢",400,200);//preido 1
  text("🏢",289,200);//predio 2
  text("🏨",490,200);//hospital
  text("🏣",290,250);//mercado
  text("🏪",400,250);//farmacia
  textSize(85)
  text("🏬",498,257);//loja
  textSize(70)
  text("🚓",350,310);//carro 1
  text("🚙",450,290);//caro 2
  
  
  
}